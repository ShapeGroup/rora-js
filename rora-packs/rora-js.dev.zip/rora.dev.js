
////// define window states

onDomTreeReading = (X) => {

    var DocReading = document.onreadystatechange;
    document.onreadystatechange = () => {
        if (DocReading) { DocReading(); }; X();
        console.debug("▒▒▒ rora : dom three status colling >>> Dom Tree under reading (load and reload)\n▒▒▒        └[info: low cpu and doesn't consider the extra fires called]");
    }

}

onDomTreeReaded = (X) => {

    var DocReady = document.onreadystatechange;
    document.onreadystatechange = () => {

        if (document.readyState === "complete") {
            if (DocReady) { DocReady(); }; X();
            console.log("▒▒▒ rora : dom three status colling >>> after Dom Tree is Ready and loaded\n▒▒▒        └[info: low cpu and doesn't consider the extra fires called]");
        }

    }

}

onContentIsLoaded = (X) => {

    var winload = window.onload;
    window.onload = () => {

        if (winload) { winload(); }; X();

        console.log("▒▒▒ rora : content status colling >>> after all Content is Loaded \n▒▒▒        └[info: all images, css, scripts, etc. are loaded, final page rendered]");

    }

}

onWindowUnload = (X) => {

    var WinUn = window.onunload;
    window.onunload = () => {

        if (WinUn) { WinUn(); }; X();

        console.log("▒▒▒ rora : content status colling >>> window start or exit \n▒▒▒└ (info: perfect to intercept hystory frame etc.)\n\n");

    }

}



/* rora haguruma */
onDomTreeReaded(() => {


    console.log("▒▒▒ rora : starting...")
    console.time("▒▒▒ rora : ready | loaded in:");

    ////// define the multiElem of doc

    doc = window.document;

    let flow = { list: "no elements or targets" };
    let node = { html: "node empty" };
    let collection = { html: "collection is empty" };


    ////// define the (doc/finded) target


    doc.find = (subjectName) => {

        let name, El, ElLast, nameNumber, childSelected, elements,
            F = new RegExp(":first-child"), isFEl = F.test(subjectName),
            L = new RegExp(":last-child"), isLEl = L.test(subjectName),
            N = new RegExp(":nth"), isNEl = N.test(subjectName);

        if (subjectName === "window") { alert("▒▒▒ ERROR ▒▒▒\n\n -''window'' is not available target for find.\n\n"); }
        else if (subjectName === "document") { alert("▒▒▒ ERROR ▒▒▒\n\n -''document'' is not available target for find.\n\n - Remember: the ''doc.'' is the document!\n - If you are looking for the general contentin your viewport, try with body.\n\n"); }

        else if (subjectName === "body") {
            elements = Array.from(document.querySelectorAll("BODY"));
        }
        else if (isFEl) {
            name = subjectName.split(":")[0];
            El = document.querySelectorAll(name)[0];
            elements = [];
            elements.push(El)
        }
        else if (isLEl) {
            name = subjectName.split(":")[0];
            El = document.querySelectorAll(name);
            ElLast = El[El.length - 1];
            elements = [];
            elements.push(ElLast)
        }
        else if (isNEl) {
            name = subjectName.split(":")[0];
            nameNumber = subjectName.split(":nth-child(")[1]; childSelected = nameNumber.split(")")[0];
            El = document.querySelectorAll(name)[(childSelected - 1)];
            elements = [];
            elements.push(El)
        }
        else {
            elements = Array.from(document.querySelectorAll(subjectName));
        }

        if (!Array.isArray(elements)) { alert("▒▒▒ ERROR ▒▒▒\n\n -The type of find is not an array!\n\n") };

        flow.list = elements;

        return flow;
    }

    flow.find = () => { alert("▒▒▒ ERROR ▒▒▒\n\n - bad pratic on find.\nIs Not good create a follow of follow [...] of follow finded element\n\n"); };


    ////// work the target property


    doc.loop = (target, back) => {
        
        let List;
        if (target == "[object Object]") {
            List = Object.values(target)[0];
            //alert("loop target is [object Object]... transformed: \n"+List);
        }
        else if (!Array.isArray(target)) {
            List = [target];
            //alert("loop target isn't Array... transformed: \n" + List);
        }
        else {
            //alert("loop target isn't conformed... get the last flow: \n" + List);
            List = flow.list;
        }

        for (let i = 0; i < List.length; i++) {
            node.html = List[i];
        } collection.html = flow.list;
        back(collection,node);
            
        return flow;  //after loop following function
    };

    flow.loop = (back) => {
        let List = flow.list;
        for (let i = 0; i < List.length; i++) {
            node.html = List[i];
            collection.html = flow.list;
        }
        back(collection, node);
        return flow;  //after loop following function
    };

    collection.loop = () => {
        alert("▒▒▒ ERROR ▒▒▒\n\n - detect: collection.loop \n\n- you can't use loop for loop! Create new flow loop or actor or function!\n- Read console.info\n\n");
        console.info("\n▒▒▒ rora : Loop Method - collection info >>> you can't use loop for loop...\n\n    [iNFO] The loop builds and analyzes a singular array. That's valid only for that loop.\n           It is a wrong practice to cycle the result of a pre-cycle, it will\n           lead to errors within the javascript object.\n\n    [TiPS] In many cases we use the for / loop to target content.\n           If you used loop, collection and node to find the target (not recommended but possible), save it and\n           continue in a new function with doc.find(new target).\n\n");
    };
    node.loop = () => {
        alert("▒▒▒ ERROR ▒▒▒\n\n - detect: node.loop \n\n- you can't use loop for only one object! Create new flow action, actor or function!\n- Read console.info\n\n");
        console.info("\n▒▒▒ rora : Loop Method - node info >>> you can't use loop for node....\n\n    [iNFO] The loop analyzes an array object. When you use loop node, you are asking the loop to\n           analyze node by node as long as it is active.You can wait for terms and add\n           methods to its result(see flow) or, alternatively, you can enter a function and get the result back(see actor).\n\n    [TiPS] Tips: In many cases we use the for\loop to target content. If you used loop, collection and node\n           to find the target (not recommended but possible), save it\n           and continue in a new function with doc.find(new target).\n\n");
    };

    ////// create dom modders


    doc.mods = (target, todo, what) => {
        let List; "[object Object]" == target ? List = Object.values(target)[0] : Array.isArray(target) ? List = flow.list : List = [target];
        DocModder(List, todo, what);
        return flow;
    };

    flow.mods = (todo, what) => {
        let List = flow.list;
        DocModder(List, todo, what);
        return flow;
    };

    collection.mods = (todo, what) => {
        let List = [...collection.html];
        DocModder(List, todo, what);
        return (collection);  //after loop following function
    };

    node.mods = (todo, what) => {
        let List = [node.html];
        DocModder(List, todo, what);
        return (node, collection, result); //follow inner flow
    };

    function DocModder(List, todo, what) {

        for (let i = 0; i < List.length; i++) {

            let el = List[i];

            switch (todo) {

                case "get-css":
                    result = window.getComputedStyle(el, null).getPropertyValue(what);
                    break;

                case "get-attr":
                    result = el.getAttribute(what);
                    break;

                case "new-attr":
                    result = el.setAttribute(what[0], what[1]);
                    break;

                case "add-attr":

                    (function () {

                        let attrType = what[0],
                            vals = el.getAttribute(attrType);

                        if (el.getAttribute(attrType) == undefined) {
                            result = el.setAttribute(attrType, what[1]);
                        }
                        else {
                            result = el.setAttribute(attrType, vals + " " + what[1]);
                        }

                    }());

                    break;

                case "set-attr":

                    (function setattr() {

                        if (el.hasAttribute(what[0])) {

                            let attrType = what[0].replace(/ /g, ''),
                                attrPara = what[1];

                            let exVal, allnewparams;

                            let ddots = new RegExp(":"), haveSwitcher = ddots.test(attrPara);

                            if (haveSwitcher || attrType == "style") {
                                exVal = el.getAttribute(attrType).replace(/ /g, '');
                                allnewparams = attrPara.replace(/; /g, ';').split(';');
                            }
                            else if (!haveSwitcher) {
                                exVal = el.getAttribute(attrType).split(' ');
                                allnewparams = attrPara.replace(/ /g, '').split(';');
                            }
                            else {
                                exVal = undefined;
                                allnewparams = undefined;
                            }


                            for (let X = 0; X < allnewparams.length; X++) {

                                let newVal = allnewparams[X];

                                let targetparam = "/" + newVal.split(':')[0] + "/";
                                if (targetparam != "//") {

                                    let ex_values;
                                    if (attrType == "style") {
                                        ex_values = el.getAttribute(attrType).replace(/; /g, ';').split(';');
                                    }
                                    else if (attrType != "style") {
                                        ex_values = el.getAttribute(attrType).split(' ');
                                        newVal = newVal.split(":")[1];
                                    }

                                    for (let Y = 0; Y < ex_values.length; Y++) {
                                        exVal = ex_values[Y];
                                        let exkey = "/" + exVal.split(':')[0] + "/";

                                        if (exkey != "//") {
                                            if ("" + exkey == "" + targetparam) {
                                                let _updatedAttr = el.getAttribute(attrType).replace(exVal, newVal);
                                                result = el.setAttribute(attrType, _updatedAttr);
                                                // alert("udp:" + attrType + " | ex: " + exVal + "  to: " + newVal + "\n newline: \n" + _updatedAttr);
                                            }
                                        }

                                    }
                                }
                            };
                        };
                    }());

                    break;

                case "del-attr":
                    result = el.removeAttribute(what);
                    break;


                case "add-class":
                    result = el.classList.add(what);
                    break;

                case "del-class":
                    result = el.classList.remove(what);
                    break;

                case "replace-class":
                    result = el.classList.replace(what[0], what[1]);
                    break;

                case "toggle-class":
                    result = el.classList.toggle(what);
                    break;


                case "new-wrap":
                    el.insertAdjacentHTML('beforebegin', what);
                    el.previousElementSibling.innerHTML = el.outerHTML;
                    el.remove();

                case "del-wrap":
                    el.outerHTML = el.innerHTML;


                case "write-in":
                    el.textContent = what;
                    break;


                case "code-override":
                    el.innerHTML = what;
                    break;

                case "code-prepend":
                    el.insertAdjacentHTML('afterbegin', what);
                    break;

                case "code-append":
                    el.insertAdjacentHTML('beforeend', what);
                    break;

                case "code-before":
                    el.insertAdjacentHTML('beforebegin', what);
                    break;

                case "code-after":
                    el.insertAdjacentHTML('afterend', what);
                    break;

                default: document.do(alert("▒▒▒ ERROR ▒▒▒\n\n - .mods: type of modder not recognized or non-existent!\n\n"));
            }

        }

        return (result);

    }


    ////// create on action event


    doc.on = (target, actiontype, back) => {
        let List;
        if (target == "[object Object]") { List = Object.values(target)[0]; }
        else if (!Array.isArray(target)) { List = [target]; }
        else { List = flow.list; }
        CreateEvent(List, actiontype, back);
        return flow;
    };

    flow.on = (actiontype, back) => {
        let List = flow.list;
        CreateEvent(List, actiontype, back);
        return flow;
    };

    node.on = (actiontype, back) => {
        let List = [node];
        CreateEvent(List, actiontype, back);
        //back(collection,node); it's outopass by back of event
        return (collection, node);
    };

    collection.on = (actiontype, back) => {
        let List = [...collection.html];
        CreateEvent(List, actiontype, back);
        //back(collection,node);  it's outopass by back of event
        return (collection, node);
    };

    function CreateEvent(List, actiontype, back) {

        for (let i = 0; i < (List.length); i++) {

            el = List[i];

            switch (actiontype) {

                case "click":
                    el.addEventListener('click', (e) => {
                        e.stopPropagation();

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker);

                    }, false);
                    break;

                case "doubleclick":
                    el.addEventListener('dblclick', (e) => {
                        e.stopPropagation();

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker);
                    }, false);
                    break;

                case "middleclick":
                    el.addEventListener('middleclick', (e) => {
                        e.stopPropagation();

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker);
                    }, false);
                    break;

                case "auxclick":
                    el.addEventListener('auxclick', (e) => {
                        e.stopPropagation();

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker);
                    }, false);
                    break;

                case "short-tap":

                    var shortTapTimer = 0;
                    el.addEventListener('touchstart', function (e) {
                        e.preventDefault();

                        shortTapTimer = setTimeout(function () {

                            clearTimeout(shortTapTimer);

                            node.html = List[i];
                            collection.html = [List];

                            clicker = List[i];

                            back(collection, node, clicker);

                        }, 700);

                    }, false);
                    el.addEventListener('touchend', function (e) {
                        e.preventDefault();
                        clearTimeout(shortTapTimer);
                    }, false);

                    break;

                case "long-tap":

                    var longTapTimer = 0;
                    el.addEventListener('touchstart', function (e) {
                        e.preventDefault();
                        longTapTimer = setTimeout(function () {
                            clearTimeout(longTapTimer);

                            node.html = List[i];
                            collection.html = [List];

                            clicker = List[i];

                            back(collection, node, clicker);
                        }, 1300);
                    }, false);
                    el.addEventListener('touchend', function (e) {
                        e.preventDefault();
                        clearTimeout(longTapTimer);
                    }, false);

                    break;

                case "mouse-enter":
                    el.addEventListener('mouseover', (e) => {
                        e.preventDefault();

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker);
                    });
                    break;

                case "mouse-exit":
                    el.addEventListener('mouseout', (e) => {
                        e.preventDefault();

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker);
                    });
                    break;

                case "mouse-move":
                    el.addEventListener('mousemove', (e) => {
                        e.preventDefault();

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker);
                    });
                    break;

                case "scroll":
                    window.addEventListener('scroll', (el) => {

                        var viewportdistance = {
                            top: 0,
                            left: 0,
                            bottom: 0,
                            right: 0
                        };
                        var eldistance = {
                            top: 0,
                            left: 0,
                            bottom: 0,
                            right: 0
                        };

                        viewportdistance.top = window.pageYOffset;
                        viewportdistance.left = window.pageXOffset;
                        viewportdistance.bottom = window.pageYOffset + window.innerHeight;
                        viewportdistance.right = window.pageXOffset + window.innerWidth;

                        eldistance.top = List[i].offsetTop;
                        eldistance.left = List[i].offsetLeft;
                        eldistance.right = List[i].offsetRight;
                        eldistance.bottom = List[i].offsetBottom;

                        ViewportDistance = viewportdistance;
                        ElementDistance = eldistance;

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, ViewportDistance, ElementDistance);

                    });
                    break;

                case "swipe":
                case "drag-on":
                case "drag-left":
                case "drag-right":
                case "drag-down":
                case "drag-up":

                    let swipedir,
                        touchArea,
                        startX, startY,
                        distX, distY,
                        threshold = 150, //required min distance traveled to be considered swipe
                        restraint = 100, // maximum distance allowed at the same time in perpendicular direction
                        allowedTime = 300, // maximum time allowed to travel that distance
                        elapsedTime,
                        startTime;

                    var drg = {
                        axis: { top: 0, right: 0, left: 0, bottom: 0 },
                        direction: { up: 0, down: 0, left: 0, right: 0 }
                    };

                    el.addEventListener('touchmove', function (e) {

                        if (actiontype != "drag") { e.preventDefault() /* prevent swipe scrolling */ }

                        touchArea = e.changedTouches[0];
                        movementX = touchArea.pageX,
                            movementY = touchArea.pageY;

                        if (actiontype == "drag-on") {

                            drg.axis.top = (startY - movementY) * -1;
                            drg.axis.bottom = (startY - movementY);
                            drg.axis.right = (startX - movementX);
                            drg.axis.left = (startX - movementX) * -1;

                        }
                        if (actiontype == "drag-left") {

                            if (startX - movementX >= 0) {
                                drg.direction.left = (startX - movementX);
                            }
                            else { drg.direction.left = 0; }
                        }
                        else if (actiontype == "drag-right") {

                            if (startX - movementX <= 0) {
                                drg.direction.right = (startX - movementX) * -1;
                            }
                            else { drg.direction.right = 0; }
                        }
                        else if (actiontype == "drag-down") {

                            if (startY - movementY <= 0) {
                                drg.direction.up = (startY - movementY) * -1;
                            }
                            else { drg.direction.up = 0; }
                        }
                        else if (actiontype == "drag-up") {

                            if (startY - movementY >= 0) {
                                drg.direction.up = (startY - movementY);
                            }
                            else { drg.direction.up = 0; }
                        }
                        if (actiontype.startsWith("drag")) {
                            drag = drg;
                            node.html = List[i];
                            collection.html = [List];

                            clicker = List[i];

                            back(collection, node, clicker, drag);
                        }

                        e.preventDefault();

                    }, false);

                    el.addEventListener('touchstart', function (e) {

                        touchArea = e.changedTouches[0];
                        swipedir = 'none',
                            dist = 0,
                            startX = touchArea.pageX,
                            startY = touchArea.pageY,
                            startTime = new Date().getTime();

                        e.preventDefault()
                    }, false);

                    el.addEventListener('touchend', function (e) {

                        touchArea = e.changedTouches[0],
                            distX = touchArea.pageX - startX,
                            distY = touchArea.pageY - startY,
                            elapsedTime = new Date().getTime() - startTime;

                        let stop = elapsedTime <= allowedTime, act = actiontype; //rewrited short vars

                        if (act == "swipe" && stop) {
                            if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) {
                                swipedir = (distX < 10) ? 'left' : 'right'
                            }
                            else if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint) {
                                swipedir = (distY < 10) ? 'up' : 'down'
                            }
                        }
                        else if (act == "swipe-x" && stop) {
                            if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) {
                                swipedir = (distX < 10) ? 'left' : 'right'
                            }
                        }
                        else if (act == "swipe-y" && stop) {
                            if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint) {
                                swipedir = (distY < 10) ? 'up' : 'down'
                            }
                        }
                        else if (act == "swipe-up" && stop) {
                            if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint) {
                                if (distY < 10) { swipedir = 'up' };
                            }
                        }
                        else if (act == "swipe-down" && stop) {
                            if (elapsedTime <= allowedTime) {
                                if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint) {
                                    if (distY > 10) { swipedir = 'down' };
                                }
                            }
                        }
                        else if (actiontype == "swipe-left" && stop) {
                            if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) {
                                if (distX < 10) { swipedir = 'left' };
                            }
                        }
                        else if (actiontype == "swipe-right" && stop) {
                            if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) {
                                if (distX > 10) { swipedir = 'right' };
                            }
                        }

                        if (swipedir) {
                            swipedirection = swipedir;
                        }

                        collection.html = [List];
                        node.html = List[i];

                        clicker = List[i];

                        back(collection, node, clicker, swipedirection);

                        e.preventDefault();

                    }, false)

                    break;

                case "stop-drag":
                    ['mouseout', 'mouseup', 'touchend'].forEach(function (e) {
                        el.addEventListener(e, () => {

                            node.html = List[i];
                            collection.html = [List];

                            clicker = List[i];

                            back(collection, node, clicker);
                        });
                    });
                    break;

                default: document.do(alert("▒▒▒ ERROR ▒▒▒\n\n - Error in ''.on'': type or target of event not recognized or non-existent.\n\n"));

            }

        }

    };


    ////// create an actor


    doc.actor = (target, fname, back) => {
        let List;
        if (target == "[object Object]") {
            List = Object.values(target)[0];
        }
        else if (!Array.isArray(target)) {
            List = [target];
        }
        else {
            List = flow.list;
        }
        CallActor(List, fname, back);
        return flow;
    };

    flow.actor = (fname, back) => {
        let List = flow.list;
        CallActor(List, fname, back);
        return flow;
    };

    collection.actor = (back) => {
        let List = Object.values(collection.html)[0];
        CallActor(List, fname, back);
        return flow;
    };

    node.actor = (fname, back) => {
        let List = [node.html];
        CallActor(List, fname, back);
        return flow;
    };

    function CallActor(List, fname) {
        for (var i = 0; i < List.length; i++) {
            fname.call(List[i])(back);
        };

    };

    ////// create on include event


    doc.include = (target, path) => {
        let List;
        if (target == "[object Object]") { List = Object.values(target)[0]; }
        else if (!Array.isArray(target)) { List = [target]; }
        else { List = flow.list; }
        include(List, path);
        return flow;
    };

    flow.include = (path) => {
        let List = flow.list;
        include(List, path);
        return flow;
    };

    collection.include = (path) => {
        let List = Object.values(collection.html)[0];
        include(List, path);
        return flow;
    };

    node.include = (path) => {
        let List = [node.html];
        include(List, path);
        return flow;
    };

    var FromDataInclude = document.querySelectorAll('div[data-include]');
    for (i = 0; i < FromDataInclude.length; i++) {
        let List = [...FromDataInclude];
        include(List);
    };

    function include(List, path) {

        console.info("▒▒▒ rora : include Tecnique >>> The tecnique of include wait the server repons...  for including action.");

        var data = path;

        for (let i = 0; i < List.length; i++) {

            let el = List[i];

            if (path == undefined) {
                //var directinclude = true;
                data = List[i].getAttribute("data-include");
            }

            if (data) {

                //check the path error
                if (data.startsWith("/")) {
                    alert("▒▒▒ ERROR ▒▒▒\n\n - include file path: do not use the ' / ' as initial.\n\n\Follow the example below:\n<div include='myfolder/.../file.html'></div>\n\n");
                    let mex = '<p style="background:white !important; padding:20px !important; border: 1px solid red !important; color:red !important; font-weight:bold !important;"> !! ERROR: WRONG PATH FOR INCLUDE</p>';
                    el.innerHTML = mex;
                };

                //create HTTP request
                let request = new XMLHttpRequest();
                request.onload = function ()
                //request.onreadystatechange = function ()  //simple alternative
                {

                    if (this.status == 200) // if ok
                    {
                        console.log("▒▒▒ rora : included file >>> " + data + " | request status: " + this.status + " | data printed:(for see active line 813)" /* \n\n+ this.responseText*/);
                        el.innerHTML = this.responseText;
                        if (el.matches('[data-include]')) {
                            // unwrap
                            el.outerHTML = el.innerHTML;
                        }
                    }
                    else if (this.status == 404) // if ok... but not found
                    {
                        alert("▒▒▒ ERROR ▒▒▒\n\n - include file path or server:\n404 file not founded.\n\n");
                    }
                    else if (this.status == 403) // if ok... but not found
                    {
                        alert("▒▒▒ ERROR ▒▒▒\n\n - include file fobidden:\n403 request not valid.\n\n");
                    }
                    else if (this.status != (404 && 0 && 200)) // if... wtf!??
                    {
                        alert("▒▒▒ ERROR ▒▒▒\n\n - include: undefined server error on include js.\n\n");
                    }

                }

                // send all... and exit
                request.open("GET", data, true);
                request.send();
            }

        }

        //if(directinclude) { return this; }
    };

    onContentIsLoaded(() => {  // create on include injection action

        setTimeout(() => {

            console.info("▒▒▒ rora : injection Tecnique >>> The tecnique of inject wait 150ms extra  (only once) for loading all including.");

            doc.find("* [data-injector]").loop((collection, node) => {

                let roles = node.mods("get-attr", "data-injector"),
                    action = String(roles.split(",")[0]);

                collection.on(action, () => {

                    roles = node.html.getAttribute("data-injector"),
                        target = String(roles.split(",")[1]),
                        path = String(roles.split(",")[2]);

                    doc.find(target).include(path);

                    console.log("▒▒▒ rora : injection Tecnique >>> action: " + action + " > on target " + target + " > calling " + path);

                });

            });

        }, 150); // 4 what?

    });


    ////// create an ajax calling


    doc.talk = (sendType, asyncMode, responseType, pageAddress, back) => {

        let response = {
            start: false + "status undefined",
            data: "data request undefined",
            success: false + "status undefined"
        };

        if (pageAddress) {

            let request = new XMLHttpRequest();

            request.onload = function () {

                if (this.readyState == 4) {
                    response.start = true;

                    if (this.status == 200) {
                        if (responseType == "output-xml") {
                            response.data = this.responseXML;
                        }
                        else if (responseType == "output-text") {
                            response.data = this.responseText;
                        }

                        response.success = true;

                    }

                }
                else if (this.readyState == 0) {
                    response.status = "error";
                    alert("▒▒▒ ERROR ▒▒▒\n\n - Error // talking fail: Server not response\n\n");
                }
                else if (this.status == 403) // if ok... but adios
                {
                    response.status = "forbidden";
                    alert("▒▒▒ ERROR ▒▒▒\n\n - Error // talking fail: forbidden requests\n\n");
                }
                else if (this.status == 404) // if ok... but not found
                {
                    response.status = "404 not found";
                    alert("▒▒▒ ERROR ▒▒▒\n\n - Error // talking fail: server 404 not found.\n\n");
                }
            }


            // send all...
            if (asyncMode == "mode-server") { asyncMode = false }
            else if (asyncMode == "mode-unlinear") { asyncMode = true }
            else { alert("▒▒▒ ERROR ▒▒▒\n\n - Error // talking fail: you can us mode-server or mode-unlinear.\n\n- server is syncronus server request, unlinear = unsync page request.\n\n"); }
            if (sendType == "type-get") { sendType = "Get" }
            else if (sendType == "type-post") { sendType = "Post" }
            else { alert("▒▒▒ ERROR ▒▒▒\n\n - Error // talking fail: you can us type-get or type-post.\n\n- Get is for small data, Post is for complex data.\n\n"); }
            request.open(sendType, pageAddress, asyncMode);
            request.send();


        }
        else { alert("▒▒▒ ERROR ▒▒▒\n\n - Error // talking fail: page, server or path not recognized.\n\n"); };

        back(response);

    };

    console.timeEnd("▒▒▒ rora : ready | loaded in:");

});